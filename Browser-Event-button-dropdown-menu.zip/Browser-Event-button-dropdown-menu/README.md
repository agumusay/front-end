# Button with a dropdown

The button consists of 2 parts:

## Select button

On click on the select button, the button should look selected (take a look in the css).
On the next click, the button should look deselected.

## Dropdown

The dropdown button is opens a dropdown (but does not change the entire button to selected or not selected).
When the user clicks anywhere on the page the dropdown should close.