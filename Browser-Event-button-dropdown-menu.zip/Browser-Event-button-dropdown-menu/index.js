let container = document.querySelector(".action-button");

// let toggleOpen = el => {
//   el.dataset.dropdown = el.dataset.dropdown === "open" ? "closed" : "open";
// };
container.addEventListener("click", event => {
  if (!event.currentTarget.classList.contains("selected")) {
    event.currentTarget.classList.add("selected");
  } else {
    event.currentTarget.classList.remove("selected");
  }

  if (event.target.dataset.dropdown === "closed") {
    event.stopPropagation();
    event.target.dataset.dropdown = "open";
  } else {
    event.stopPropagation();
    event.target.dataset.dropdown = "closed";
  }
});

document.addEventListener("click", event => {
  document.querySelector("[data-dropdown]").dataset.dropdown = "closed";
});
