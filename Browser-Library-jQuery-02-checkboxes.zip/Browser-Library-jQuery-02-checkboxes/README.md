# Selected items

Update the sentence when checkboxes get selected or deselected.

![example empty](example-empty.png)

When two are selected connect the selected options with `and`: 

![example two selected](example-two-selected.png)

When many are selected, connect the selected options  with `,`: 

![example many selected](example-many-selected.png)

On inital load, if a checkbox is selected by default, the sentence should also be correctly displayed.

Extra:

Add toggle to hide or show all checkboxes.

> use jQuery