$(document).ready(function () {
    let defaultVal = $('input[name="food"]:checked').serialize().replace('food=', '');
    $('span').text(defaultVal);
    $("form").change(function (event) {
        event.preventDefault();
        let arrayOfValues = $('input[name="food"]:checked').serialize().split('&').map(ele => ele.replace('food=', ''))
        console.log(arrayOfValues)
        if (arrayOfValues[0] == '') {
            $('span').text('...');
        } else if (arrayOfValues.length == 2) {
            $('span').text(arrayOfValues.join(' and '));
        } else {
            $('span').text(arrayOfValues.join(', '));
        }
    });
    $('input[name="deselect"]').change(function (event) {
        event.preventDefault();
        $('input[type="checkbox"]').prop('checked', false);
    })
});